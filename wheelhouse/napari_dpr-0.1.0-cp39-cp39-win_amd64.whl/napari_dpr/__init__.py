"""
napari-dpr plugin package.
"""

__version__ = "0.1.0"

# Import modules for easier access
from napari_dpr.dpr_core import *
from napari_dpr.dpr import * 